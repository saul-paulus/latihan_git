# jwt-best-practices

From the tutorial written [here](https://www.nexmo.com/blog/2020/03/13/using-jwt-for-authentication-in-a-golang-application-dr)


You can get the complete code that include middlewares and separated into packages from [here](https://github.com/victorsteven/gophercon-jwt-repo)

And the youtube [tutorial series](https://www.youtube.com/watch?v=RKV__1-YKHE&list=PLk73vnn5oQQbcI7Tt0rlQ0WUoV8mbYoma)

